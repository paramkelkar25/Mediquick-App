package com.example.mediquick.backend.interfaces;

import com.example.mediquick.backend.models.PharmacyRequest;

import java.util.List;

public interface PharmacyOrdersCallback {
    void onOrdersReceived(List<PharmacyRequest> orders);
    void onError(String error);
}

