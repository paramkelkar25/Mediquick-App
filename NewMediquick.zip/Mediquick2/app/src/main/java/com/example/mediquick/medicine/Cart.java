package com.example.mediquick.medicine;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.mediquick.loginSignup.HomePage;
import com.example.mediquick.R;
import com.example.mediquick.medicine.PaymentActivity;


import java.util.ArrayList;

public class Cart extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<priceHolder> itemList;
    TextView totalAmount;
    Button placeOrder, btoHome;
    double totalPrice = 0.0; // Store the total price

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cart);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.BillView);
        placeOrder = findViewById(R.id.placeOrder);
        btoHome = findViewById(R.id.BackToHome);
        totalAmount = findViewById(R.id.totalAmount);

        // Get order data from Intent
        Intent intent = getIntent();
        Bundle args = intent.getBundleExtra("Bundle");

        if (args != null) {
            itemList = (ArrayList<priceHolder>) args.getSerializable("order");
            if (itemList == null) {
                itemList = new ArrayList<>();
            }
        } else {
            itemList = new ArrayList<>();
        }

        // Calculate total amount
        // Calculate total amount safely
        for (priceHolder item : itemList) {
            try {
                totalPrice += Double.parseDouble(item.getPrice()); // Convert string to double
            } catch (NumberFormatException e) {
                Log.e("Cart", "Invalid price format: " + item.getPrice());
            }
        }


        // Display total amount
        totalAmount.setText("Total: ₹" + totalPrice);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new billViewAdapter(getApplicationContext(), itemList));

        // Place Order - Navigate to PaymentActivity
        placeOrder.setOnClickListener(v -> {
            Intent paymentIntent = new Intent(Cart.this, PaymentActivity.class);
            paymentIntent.putExtra("totalAmount", totalPrice);
            startActivity(paymentIntent);
        });

        // Back to Home
        btoHome.setOnClickListener(v -> {
            Intent homeIntent = new Intent(Cart.this, HomePage.class);
            startActivity(homeIntent);
            finish();
        });
    }
}
