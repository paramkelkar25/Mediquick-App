package com.example.mediquick.loginSignup;

import com.example.mediquick.medicine.medicalModel;

public interface SelectListner {
    void onItemClicked(medicalModel medicalModel);
}
