package com.example.mediquick.general;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mediquick.R;
import com.example.mediquick.backend.BackendManager;
import com.example.mediquick.backend.interfaces.DoctorListCallback;
import com.example.mediquick.backend.models.Doctor;

import java.util.ArrayList;
import java.util.List;

import kotlin.coroutines.CoroutineContext;

public class generalSelector extends AppCompatActivity {
    private RecyclerView recyclerView;
    private generalAdapter generalAdapter;
    private List<general> generalList;

    private BackendManager dbManager = new BackendManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_selector);

        recyclerView = findViewById(R.id.recyclerViewDoctors);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Doctor> generalDoctors = new ArrayList<>();

        dbManager.getAllDoctors(new DoctorListCallback() {
            @Override
            public void onSuccess(List<Doctor> doctors) {
                generalDoctors.clear();  // Clear any previous data
                generalDoctors.addAll(doctors);

                Log.d("doctors", "Doctors fetched: " + generalDoctors.toString());

                // Set up adapter *after* data is fetched
                generalAdapter adapter = new generalAdapter(generalSelector.this, generalDoctors);
                recyclerView.setAdapter(adapter);
                recyclerView.setHasFixedSize(true);
            }

            @Override
            public void onFailure(String errorMessage) {
                Log.e("doctors", "Error: " + errorMessage);
            }
        });

    }
}
