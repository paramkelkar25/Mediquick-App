package com.example.mediquick.backend.interfaces;

public interface AppointmentCallback {
    void onAppointmentRequest(boolean success, String message, String appointmentId);
}


