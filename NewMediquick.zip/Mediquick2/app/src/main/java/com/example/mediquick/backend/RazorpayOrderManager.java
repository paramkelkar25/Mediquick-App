// File: RazorpayOrderManager.java (inside your backend module)
package com.example.mediquick.backend;

import android.util.Base64;
import android.util.Log;

import com.google.gson.Gson;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class RazorpayOrderManager {
    private static final String RAZORPAY_KEY_ID = "rzp_test_IoHm0WZE7BP1xA";
    private static final String RAZORPAY_KEY_SECRET = "jDPUd4dY7phCAhAKe1z87sfm";

    public interface OrderCallback {
        void onOrderCreated(String orderId);
        void onError(String error);
    }

    public void createOrder(double amount, String currency, OrderCallback callback) {
        new Thread(() -> {
            try {
                URL url = new URL("https://api.razorpay.com/v1/orders");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");

                // Basic Auth Header
                String auth = RAZORPAY_KEY_ID + ":" + RAZORPAY_KEY_SECRET;
                String encodedAuth = Base64.encodeToString(auth.getBytes(), Base64.NO_WRAP);
                conn.setRequestProperty("Authorization", "Basic " + encodedAuth);
                conn.setRequestProperty("Content-Type", "application/json");

                Map<String, Object> orderData = new HashMap<>();
                orderData.put("amount", (int)(amount * 100)); // in paise
                orderData.put("currency", currency);
                orderData.put("receipt", "receipt_" + System.currentTimeMillis());
                orderData.put("payment_capture", 1);

                String json = new Gson().toJson(orderData);
                OutputStream os = conn.getOutputStream();
                os.write(json.getBytes());
                os.flush();

                if (conn.getResponseCode() == 200 || conn.getResponseCode() == 201) {
                    String response = new java.util.Scanner(conn.getInputStream()).useDelimiter("\\A").next();
                    String orderId = new org.json.JSONObject(response).getString("id");
                    callback.onOrderCreated(orderId);
                } else {
                    callback.onError("Failed to create order. Code: " + conn.getResponseCode());
                }
            } catch (Exception e) {
                callback.onError("Exception: " + e.getMessage());
                Log.e("Razorpay", "Order creation failed", e);
            }
        }).start();
    }
}

