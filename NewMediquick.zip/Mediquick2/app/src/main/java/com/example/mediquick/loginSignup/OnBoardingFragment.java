package com.example.mediquick.loginSignup;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.mediquick.R;
import com.example.mediquick.backend.models.User;
import com.google.android.material.textfield.TextInputLayout;

public class OnBoardingFragment extends Fragment {


    public OnBoardingFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_on_boarding, container, false);

        TextInputLayout fullName = view.findViewById(R.id.onBoardingScreenFullNameInputLayout);
        TextInputLayout phoneNumber = view.findViewById(R.id.onBoardingScreenPhoneInputLayout);
        TextInputLayout DOB = view.findViewById(R.id.onBoardingScreenDOBInputLayout);
        Button backBtn = view.findViewById(R.id.onBoardingScreenBackButton);
        Button nextBtn = view.findViewById(R.id.onBoardingScreenNextButton);

        backBtn.setOnClickListener(v-> {
            Intent intent = new Intent(getActivity(), RegisterScreen.class);
            startActivity(intent);
        });

        nextBtn.setOnClickListener(v-> {
            if (fullName.getEditText().getText().toString().isEmpty()
                    || phoneNumber.getEditText().getText().toString().isEmpty()
                    || DOB.getEditText().getText().toString().isEmpty()) {
                Toast.makeText(getActivity(), "All fields are required", Toast.LENGTH_SHORT).show();
            } else {
                User user = new User(
                        fullName.getEditText().getText().toString(),
                        phoneNumber.getEditText().getText().toString(),
                        "", // Address will be set in the second onboarding step
                        "", // Gender will be set in the second onboarding step
                        DOB.getEditText().getText().toString(),
                        ""  // BloodGroup will be set in the second onboarding step
                );

                ((OnBoardingScreen) requireActivity()).receiveUserData(user);

                getParentFragmentManager().beginTransaction()
                        .replace(R.id.onBoardingScreenFragmentContainer, new OnBoardingFragmentPart2())
                        .addToBackStack("Part2")
                        .commit();
            }
        });
        return view;
    }
}