package com.example.mediquick.backend.interfaces;

import com.example.mediquick.backend.models.PharmacyRequest;

public interface MedicineOrderDetailsCallback {
    void onOrderDetailsReceived(PharmacyRequest order);
    void onError(String error);
}

