package com.example.mediquick.medicine;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.R;
import com.example.mediquick.backend.RazorpayOrderManager;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class PaymentActivity extends AppCompatActivity implements PaymentResultListener {

    private double finalAmount = 100.0; // From Cart
    private String userName = "Param Kelkar"; // Optional
    private String contactNumber = "9898057282"; // Optional
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        Double paymentAmount = getIntent().getDoubleExtra("totalAmount", 0.0);
        finalAmount = paymentAmount;
        TextView totalAmount = findViewById(R.id.totalAmount);
        totalAmount.setText(String.valueOf(paymentAmount));

        // Optional: Replace hardcoded values with real data
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid(); // Get UID from FirebaseAuth

        findViewById(R.id.placeOrder).setOnClickListener(v -> {
            new RazorpayOrderManager().createOrder(finalAmount, "INR", new RazorpayOrderManager.OrderCallback() {
                @Override
                public void onOrderCreated(String orderId) {
                    runOnUiThread(() -> startRazorpayCheckout(orderId));
                }

                @Override
                public void onError(String error) {
                    runOnUiThread(() ->
                            Toast.makeText(PaymentActivity.this, error, Toast.LENGTH_LONG).show());
                }
            });
        });
    }

    private void startRazorpayCheckout(String orderId) {
        Checkout checkout = new Checkout();
        checkout.setKeyID("rzp_test_IoHm0WZE7BP1xA"); // Replace with your Razorpay Key ID

        try {
            JSONObject options = new JSONObject();
            options.put("name", "MediQuick");
            options.put("description", "Medicine Order");
            options.put("order_id", orderId);
            options.put("currency", "INR");
            options.put("amount", (int) (finalAmount * 100));

            JSONObject prefill = new JSONObject();
            prefill.put("email", "kelkarparam2025@gmail.com"); // Optional
            prefill.put("contact", contactNumber); // Optional

            options.put("prefill", prefill);

            checkout.open(this, options);
        } catch (Exception e) {
            Log.e("Razorpay", "Checkout launch error", e);
        }
    }

    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Map<String, Object> paymentRecord = new HashMap<>();
        paymentRecord.put("amount", finalAmount);
        paymentRecord.put("paymentId", razorpayPaymentID);
        paymentRecord.put("userId", userId); // Changed from userEmail to userId
        paymentRecord.put("timestamp", System.currentTimeMillis());

        DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference("Payments");
        String uniqueKey = databaseRef.push().getKey(); // Generate unique ID

        if (uniqueKey != null) {
            databaseRef.child(uniqueKey)
                    .setValue(paymentRecord)
                    .addOnSuccessListener(aVoid ->
                            Toast.makeText(this, "Payment Successful!", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Failed to save payment!", Toast.LENGTH_SHORT).show());
        } else {
            Toast.makeText(this, "Failed to generate payment record ID", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onPaymentError(int i, String s) {
        Log.d("payment","payment incomplete");
    }
}