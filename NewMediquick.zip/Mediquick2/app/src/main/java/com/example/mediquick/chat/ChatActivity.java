package com.example.mediquick.chat;

import android.os.Bundle;
import android.util.Pair;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mediquick.R;

import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {
    private RecyclerView chatRecyclerView;
    private ChatAdapter chatAdapter;
    private List<Pair<String, Boolean>> messages = new ArrayList<>(); // Using Java List instead of Kotlin MutableList

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        EditText promptInput = findViewById(R.id.edit_text);
        Button sendBtn = findViewById(R.id.btnSend);
        chatRecyclerView = findViewById(R.id.recycler_view);

        chatAdapter = new ChatAdapter((ArrayList<Pair<String, Boolean>>) messages);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        layoutManager.setReverseLayout(false);

        chatRecyclerView.setLayoutManager(layoutManager);
        chatRecyclerView.setAdapter(chatAdapter);

        sendBtn.setOnClickListener(view -> {
            String prompt = promptInput.getText().toString().trim();

            if (!prompt.isEmpty()) {
                addMessage(prompt, true);
                promptInput.setText("");

                ApiRequest.fetchResponse(this, prompt, new ApiRequest.ResponseCallback() {
                    @Override
                    public void onSuccess(String response) {
                        // Ensure `response` is a String before processing
                        String cleanResponse = response.replaceAll("[*_`#~]+", "").trim();
                        addMessage(cleanResponse, false);
                    }

                    @Override
                    public void onFailure(String error) {
                        addMessage("Error: " + error, false);
                    }
                });

            }
        });
    }

    private void addMessage(@NonNull String text, boolean isUser) {
        messages.add(new Pair<>(text, isUser));
        chatAdapter.notifyItemInserted(messages.size() - 1);
        chatRecyclerView.scrollToPosition(messages.size() - 1);
    }
}
