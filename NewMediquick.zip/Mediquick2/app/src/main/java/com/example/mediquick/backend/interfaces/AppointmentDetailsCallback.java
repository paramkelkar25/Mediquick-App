package com.example.mediquick.backend.interfaces;

import com.example.mediquick.backend.models.Appointment;

public interface AppointmentDetailsCallback {
    void onSuccess(Appointment appointment);
    void onFailure(String errorMessage);
}
