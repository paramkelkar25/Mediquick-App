package com.example.mediquick.backend.interfaces;

public interface MedicineOrderStatusCallback {
    void onSuccess(String status);
    void onFailure(String errorMessage);
}

