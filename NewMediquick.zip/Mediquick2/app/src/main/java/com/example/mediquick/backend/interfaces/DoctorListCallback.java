package com.example.mediquick.backend.interfaces;

import com.example.mediquick.backend.models.Doctor;

import java.util.List;

public interface DoctorListCallback {
    void onSuccess(List<Doctor> doctors);

    void onFailure(String errorMessage);
}
