package com.example.mediquick.backend.interfaces;

public interface FcmCallback {
    void onSuccess();
    void onFailure(String error);
}
