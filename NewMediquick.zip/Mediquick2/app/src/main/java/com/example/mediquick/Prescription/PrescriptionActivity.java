package com.example.mediquick.Prescription;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mediquick.R;
import com.example.mediquick.backend.BackendManager;
import com.example.mediquick.backend.interfaces.PrescriptionCallback;
import com.example.mediquick.backend.models.Prescription;

import java.util.ArrayList;
import java.util.List;

public class PrescriptionActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private PrescriptionAdapter adapter;
    private List<Prescription> prescriptionList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription);

        recyclerView = findViewById(R.id.recyclerPrescription);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        prescriptionList = new ArrayList<>();
        adapter = new PrescriptionAdapter(prescriptionList,this);
        recyclerView.setAdapter(adapter);

        String userId = "USER_ID_HERE"; // Replace with actual user ID from FirebaseAuth or session

        BackendManager backendManager = new BackendManager();
        backendManager.getAllUserPrescriptions(userId, new PrescriptionCallback() {
            @Override
            public void onPrescriptionsReceived(List<Prescription> prescriptions) {
                if (prescriptions != null) {
                    prescriptionList.clear();
                    prescriptionList.addAll(prescriptions);
                    adapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(PrescriptionActivity.this, "No prescriptions found", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
