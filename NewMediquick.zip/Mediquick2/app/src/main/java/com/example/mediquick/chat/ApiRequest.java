package com.example.mediquick.chat;


import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ApiRequest {
    private static final JSONArray chatHistory = new JSONArray(); // Store Chat History 🔥
    private static final String URL = "https://openrouter.ai/api/v1/chat/completions";

    private static final String API_KEY = "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"; // Replace with your API Key

    public static void fetchResponse(Context context, String message, final ResponseCallback callback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("model", "nvidia/llama-3.1-nemotron-ultra-253b-v1:free");

            // Add User Message to History
            JSONObject userMessage = new JSONObject();
            userMessage.put("role", "user");
            userMessage.put("content", message);
            chatHistory.put(userMessage);

            jsonObject.put("messages", chatHistory);

            JsonObjectRequest request = new JsonObjectRequest(
                    Request.Method.POST, URL, jsonObject,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                String content = response.getJSONArray("choices")
                                        .getJSONObject(0)
                                        .getJSONObject("message")
                                        .getString("content");

                                // Clean Markdown Formatting
                                String cleanResponse = content.replaceAll("[*_`#~]+", "").trim();

                                // Add Assistant Response to History
                                JSONObject assistantMessage = new JSONObject();
                                assistantMessage.put("role", "assistant");
                                assistantMessage.put("content", cleanResponse);
                                chatHistory.put(assistantMessage);

                                callback.onSuccess(cleanResponse);

                            } catch (JSONException e) {
                                e.printStackTrace();
                                callback.onFailure("Failed to Parse Response");
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error){
                            error.printStackTrace();
                            if (error.networkResponse != null) {
                                Log.e("ApiRequest", "HTTP Error Code: " + error.networkResponse.statusCode);
                                Log.e("ApiRequest", "Response Body: " + new String(error.networkResponse.data));
                            }
                            callback.onFailure("Failed to Fetch Response");
                        }


                    })
            {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Authorization", "Bearer " + API_KEY);
                    headers.put("Content-Type", "application/json");
                    return headers;
                }
            };

            Volley.newRequestQueue(context).add(request);

        } catch (JSONException e) {
            e.printStackTrace();
            callback.onFailure("JSON Error");
        }
    }

    public interface ResponseCallback {
        void onSuccess(String response);
        void onFailure(String error);
    }
}

