package com.example.mediquick.backend.interfaces;

import com.example.mediquick.backend.models.Appointment;

import java.util.List;

public interface DoctorAppointmentsCallback {
    void onAppointmentsReceived(List<Appointment> appointments);
    void onError(String errorMessage);
}
