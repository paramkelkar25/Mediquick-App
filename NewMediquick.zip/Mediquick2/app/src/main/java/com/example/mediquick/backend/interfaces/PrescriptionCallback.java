package com.example.mediquick.backend.interfaces;

import com.example.mediquick.backend.models.Prescription;

import java.util.List;

public interface PrescriptionCallback {
    void onPrescriptionsReceived(List<Prescription> prescriptions);
}

