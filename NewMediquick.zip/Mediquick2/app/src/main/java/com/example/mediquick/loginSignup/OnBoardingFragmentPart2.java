package com.example.mediquick.loginSignup;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.mediquick.R;
import com.example.mediquick.backend.BackendManager;
import com.example.mediquick.backend.models.User;
import com.google.android.material.textfield.TextInputLayout;

public class OnBoardingFragmentPart2 extends Fragment {

    private BackendManager dbManager;

    public OnBoardingFragmentPart2() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_on_boarding_part2, container, false);

        TextInputLayout gender = view.findViewById(R.id.onBoardingScreenGenderInputLayout);
        TextInputLayout bloodGroup = view.findViewById(R.id.onBoardingScreenBloodGroupInputLayout);
        TextInputLayout address = view.findViewById(R.id.onBoardingScreenAddressInputLayout);
        Button backBtn = view.findViewById(R.id.onBoardingScreenPart2BackButton);
        Button nextBtn = view.findViewById(R.id.onBoardingScreenPart2NextButton);

        backBtn.setOnClickListener( v-> {
            getActivity().getOnBackPressedDispatcher().onBackPressed();
        });

        nextBtn.setOnClickListener(v -> {
            String userGender = gender.getEditText().getText().toString().trim();
            String userBloodGroup = bloodGroup.getEditText().getText().toString().trim();
            String userAddress = address.getEditText().getText().toString().trim();

            if (userGender.isEmpty() || userBloodGroup.isEmpty() || userAddress.isEmpty()) {
                Toast.makeText(getContext(), "Please fill all the fields", Toast.LENGTH_SHORT).show();
            } else {
                // Create a map to store data
                User user = new User();
                user.setGender(userGender);
                user.setBloodGroup(userBloodGroup);
                user.setAddress(userAddress);

                ((OnBoardingScreen) requireActivity()).receiveUserData(user);

                Toast.makeText(getContext(), "Onboarding Complete!", Toast.LENGTH_SHORT).show();

            }
        });
        return view;
    }
}