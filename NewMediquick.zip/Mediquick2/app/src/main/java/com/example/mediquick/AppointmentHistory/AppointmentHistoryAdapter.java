package com.example.mediquick.AppointmentHistory;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mediquick.R;
import com.example.mediquick.backend.BackendManager;
import com.example.mediquick.backend.interfaces.AppointmentStatusCallback;
import com.example.mediquick.backend.interfaces.UpdateStatusCallback;
import com.example.mediquick.backend.models.Appointment;

import java.util.List;

public class AppointmentHistoryAdapter extends RecyclerView.Adapter<AppointmentHistoryAdapter.HistoryViewHolder> {

    private List<Appointment> appointments;

    public AppointmentHistoryAdapter(List<Appointment> appointments) {
        this.appointments = appointments;
    }

    @NonNull
    @Override
    public HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_appointment_history, parent, false);
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryViewHolder holder, int position) {
        // Get the current appointment object
        Appointment appointment = appointments.get(position);

        // Set text fields with data
        holder.txtAppointmentId.setText("Appointment ID: " + appointment.getAppointmentId());
        holder.txtDoctorId.setText("Doctor ID: " + appointment.getDoctorId());
        holder.txtDate.setText("Date: " + appointment.getDate());
        holder.txtStatus.setText("Status: " + appointment.getStatus());  // This will be updated later
        holder.txtDiagnosis.setText("Diagnosis: " + appointment.getDiagnosis());
        holder.txtCreatedAt.setText("Created At: " + appointment.getCreatedAt());
        holder.btnUpdateStatus.setText("Update Status:" + appointment.getStatus());

        // Call BackendManager to get the appointment status for the current appointment


        // Set OnClickListener on the 'Update Status' button
        holder.btnUpdateStatus.setOnClickListener(v -> {
            // Call BackendManager to update the status in the backend
            BackendManager db = new BackendManager();
            db.getAppointmentStatus(appointment.getAppointmentId(), new AppointmentStatusCallback() {
                @Override
                public void onSuccess(String status) {
                    // Update the status TextView when the status is fetched
                    holder.txtStatus.setText("Status: " + status);
                    // Optionally, update the status in the appointment list if needed
                    appointment.setStatus(status);
                }

                @Override
                public void onFailure(String error) {
                    // Handle failure (e.g., logging or showing a toast)
                    Log.e("AppointmentStatus", "Error: " + error);
                }
            });
        });
    }


    @Override
    public int getItemCount() {
        return appointments.size();
    }

    public static class HistoryViewHolder extends RecyclerView.ViewHolder {
        TextView txtAppointmentId, txtDoctorId, txtDate, txtStatus, txtDiagnosis, txtCreatedAt;
        Button btnUpdateStatus;

        public HistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            txtAppointmentId = itemView.findViewById(R.id.txtAppointmentId);
            txtDoctorId = itemView.findViewById(R.id.txtDoctorId);
            txtDate = itemView.findViewById(R.id.txtDate);
            txtStatus = itemView.findViewById(R.id.txtStatus);
            txtDiagnosis = itemView.findViewById(R.id.txtDiagnosis);
            txtCreatedAt = itemView.findViewById(R.id.txtCreatedAt);
            btnUpdateStatus = itemView.findViewById(R.id.btnUpdateStatus);
        }
    }
}
