package com.example.mediquick.chat;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import java.io.IOException;

public class RapidApiHelper {
    private static final String API_KEY = "f3facac2d6msha52789362c81d7fp1715c8jsn6053cdc4594b";
    private static final String API_HOST = "chatgpt-42.p.rapidapi.com";  // Example: "chatgpt-api8.p.rapidapi.com"

    public static void callApi(String userMessage, Callback callback) throws IOException {
        OkHttpClient client = new OkHttpClient();

        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}],\"web_access\":false}");
        Request request = new Request.Builder()
                .url("https://chatgpt-42.p.rapidapi.com/o3mini")
                .post(body)
                .addHeader("x-rapidapi-key", "f3facac2d6msha52789362c81d7fp1715c8jsn6053cdc4594b")
                .addHeader("x-rapidapi-host", "chatgpt-42.p.rapidapi.com")
                .addHeader("Content-Type", "application/json")
                .build();

        Response response = ((OkHttpClient) client).newCall(request).execute();

    }
}
