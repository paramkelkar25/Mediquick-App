package com.example.mediquick.chat;

public class Message {
    public static String SENT_BY_USER = "user";
    public static String SENT_BY_BOT = "bot";


    private String message;
    private boolean sentBy;

    public Message(String message, boolean sentBy) {
    }


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSentBy() {
        return sentBy;
    }

    public void setSentBy(boolean sentBy) {
        this.sentBy = sentBy;
    }
}
