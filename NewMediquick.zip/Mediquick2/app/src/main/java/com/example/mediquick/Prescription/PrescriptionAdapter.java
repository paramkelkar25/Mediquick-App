package com.example.mediquick.Prescription;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mediquick.R;
import com.example.mediquick.backend.models.Prescription;
import com.example.mediquick.medicine.medicalModel;
import com.example.mediquick.medicine.medicineSelector;

import java.util.List;

public class PrescriptionAdapter extends RecyclerView.Adapter<PrescriptionAdapter.PrescriptionViewHolder> {

    private List<Prescription> prescriptions;
    private Context context;

    public PrescriptionAdapter(List<Prescription> prescriptions, Context context) {
        this.prescriptions = prescriptions;
        this.context = context;
    }

    @NonNull
    @Override
    public PrescriptionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_prescription, parent, false);
        return new PrescriptionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PrescriptionViewHolder holder, int position) {
        Prescription prescription = prescriptions.get(position);

        holder.txtDoctorId.setText("Doctor ID: " + prescription.getDoctorId());
        holder.txtAppointmentId.setText("Appointment ID: " + prescription.getAppointmentId());
        holder.txtmedicines.setText ("Medicines:" + prescription.getMedicines());
        holder.txtInstructions.setText("Instructions: " + prescription.getInstructions());
        holder.txtCreatedAt.setText("Created At: " + prescription.getCreatedAt());
        holder.txtDeliveryStatus.setText("Delivery Status: " + prescription.getHomeDeliveryStatus());

        Button orderButton = holder.itemView.findViewById(R.id.btnOrderMedicine);
        orderButton.setOnClickListener(v -> {
            // You can pass necessary info here like prescriptionId, etc.
            Intent intent = new Intent(context, medicineSelector.class); intent.putExtra("prescriptionId", prescriptions.get(position).getPrescriptionId());
            context.startActivity(intent);
        });

    }

    @Override
    public int getItemCount() {
        return prescriptions.size();
    }

    public static class PrescriptionViewHolder extends RecyclerView.ViewHolder {
        public medicalModel txtmedicines;
        TextView txtDoctorId, txtAppointmentId, txtInstructions, txtCreatedAt, txtDeliveryStatus;

        public PrescriptionViewHolder(@NonNull View itemView) {
            super(itemView);
            txtDoctorId = itemView.findViewById(R.id.txtDoctorId);
            txtAppointmentId = itemView.findViewById(R.id.txtAppointmentId);
            txtInstructions = itemView.findViewById(R.id.txtInstructions);
            txtCreatedAt = itemView.findViewById(R.id.txtCreatedAt);
            txtDeliveryStatus = itemView.findViewById(R.id.txtDeliveryStatus);
        }
    }
}
