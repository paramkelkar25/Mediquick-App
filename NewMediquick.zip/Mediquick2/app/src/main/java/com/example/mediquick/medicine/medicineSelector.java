package com.example.mediquick.medicine;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mediquick.R;
import com.example.mediquick.loginSignup.SelectListner;

import java.io.Serializable;
import java.util.ArrayList;

public class medicineSelector extends AppCompatActivity implements SelectListner {

    RecyclerView recyclerview;
    ArrayList<medicalModel> list;
    ImageView cart;
    ArrayList<priceHolder> arrayList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicine_selector);

        recyclerview = findViewById(R.id.recyclerView2);

        cart = findViewById(R.id.Cart);

        list = new ArrayList<>();

        list.add(new medicalModel(R.drawable.crocin, "Crocin 650mg ", "Add to Cart",50));
        list.add(new medicalModel(R.drawable.paracetamol, "Paracetamol 500mg", "Add to Cart",30));
        list.add(new medicalModel(R.drawable.noyil, "Noyil 650mg", "Add to Cart",65));
        //list.add(new medicalModel(R.drawable.doc4, "", "Add to Cart",899));
        //list.add(new medicalModel(R.drawable.doc5, "", "Add to Cart",1000));
        medicineAdapter adapter = new medicineAdapter(list, this, (SelectListner) this);
        recyclerview.setAdapter(adapter);


        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerview.setLayoutManager(layoutManager);

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // PASS Array list to cart activity
                Intent intent = new Intent(medicineSelector.this, Cart.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("order",(Serializable) arrayList);
                intent.putExtra("Bundle",bundle);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onItemClicked(medicalModel medicalModel) {
        Toast.makeText(this, medicalModel.getText() + " Added to cart", Toast.LENGTH_SHORT).show();

        priceHolder v = new priceHolder();
        v.name = medicalModel.getText();
        v.price = String.valueOf(medicalModel.getPrice());
        arrayList.add(v);
    }


}