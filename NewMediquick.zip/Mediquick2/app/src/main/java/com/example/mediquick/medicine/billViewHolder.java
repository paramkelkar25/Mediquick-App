package com.example.mediquick.medicine;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mediquick.R;

public class billViewHolder extends RecyclerView.ViewHolder {

    public TextView item;
    public TextView price;

    public billViewHolder(@NonNull View itemView) {

        super(itemView);
        item = itemView.findViewById(R.id.itemHolder);
        price = itemView.findViewById(R.id.priceHolder);
    }
}