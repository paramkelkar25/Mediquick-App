package com.example.mediquick.booking;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.R;
import com.example.mediquick.backend.BackendManager;
import com.example.mediquick.backend.interfaces.FcmTokenCallback;
import com.example.mediquick.backend.models.Doctor;
import com.example.mediquick.loginSignup.HomePage;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Calendar;

public class BookingActivity extends AppCompatActivity {

    private TextView txtBookDoctor, txtSelectedDate, txtSelectedTime;
    private Button btnSelectDate, btnSelectTime, btnConfirmAppointment;
    private Doctor doctor;

    private int selectedYear, selectedMonth, selectedDay, selectedHour, selectedMinute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        txtBookDoctor = findViewById(R.id.generalListDoctorName);
        txtSelectedDate = findViewById(R.id.txtSelectedDate);
        txtSelectedTime = findViewById(R.id.txtSelectedTime);
        btnSelectDate = findViewById(R.id.btnSelectDate);
        btnSelectTime = findViewById(R.id.btnSelectTime);
        btnConfirmAppointment = findViewById(R.id.btnConfirmAppointment);

        doctor = (Doctor) getIntent().getSerializableExtra("doctor");

        if (doctor != null) {
            txtBookDoctor.setText(doctor.getName());
        }

        btnSelectDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    BookingActivity.this,
                    (view, year, month, dayOfMonth) -> {
                        selectedYear = year;
                        selectedMonth = month + 1;
                        selectedDay = dayOfMonth;
                        txtSelectedDate.setText(selectedDay + "/" + selectedMonth + "/" + selectedYear);
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
            datePickerDialog.show();
        });

        btnSelectTime.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            TimePickerDialog timePickerDialog = new TimePickerDialog(
                    BookingActivity.this,
                    (view, hourOfDay, minute) -> {
                        selectedHour = hourOfDay;
                        selectedMinute = minute;
                        txtSelectedTime.setText(String.format("%02d:%02d", selectedHour, selectedMinute));
                    },
                    calendar.get(Calendar.HOUR_OF_DAY),
                    calendar.get(Calendar.MINUTE),
                    false
            );
            timePickerDialog.show();
        });

        btnConfirmAppointment.setOnClickListener(v -> {
            if (txtSelectedDate.getText().toString().isEmpty() || txtSelectedTime.getText().toString().isEmpty()) {
                Toast.makeText(BookingActivity.this, "Please select date and time", Toast.LENGTH_SHORT).show();
            } else {
                String appointmentDate = String.format("%02d/%02d/%04d", selectedDay, selectedMonth, selectedYear);
                String appointmentTime = String.format("%02d:%02d", selectedHour, selectedMinute);

                FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                if (currentUser == null) {
                    Toast.makeText(BookingActivity.this, "User not logged in", Toast.LENGTH_SHORT).show();
                    return;
                }

                BackendManager backendManager = new BackendManager();

                // Optional: Fetch FCM token of doctor for debugging or logging
                backendManager.getSelectedDoctorToken(doctor.getDoctorId(), new FcmTokenCallback() {
                    @Override
                    public void onTokenReceived(String fcmToken) {
                        Log.d("FCM Token", "Doctor's FCM Token: " + fcmToken);
                        // Notifying doctor is handled inside generateAppointmentAndNotify
                    }

                    @Override
                    public void onFailure(String errorMessage) {
                        Log.e("FCM Token Fetch", errorMessage);
                    }
                });

                backendManager.generateAppointmentAndNotify(
                        BookingActivity.this,
                        doctor.getDoctorId(),
                        appointmentTime,
                        appointmentDate
                );

                Toast.makeText(BookingActivity.this, "Appointment request sent", Toast.LENGTH_SHORT).show();

                startActivity(new Intent(BookingActivity.this, HomePage.class));
                finish();
            }
        });
    }
}
