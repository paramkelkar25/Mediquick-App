package com.example.mediquick.backend.interfaces;

public interface MedicineOrderCallback {
    void onSuccess(String message);
    void onFailure(String error);
}
