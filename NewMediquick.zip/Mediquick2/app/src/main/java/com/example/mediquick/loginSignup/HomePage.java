package com.example.mediquick.loginSignup;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.mediquick.AppointmentHistory.AppointmentHistoryActivity;
import com.example.mediquick.R;
import com.example.mediquick.aboutActivity;
import com.example.mediquick.chat.ChatActivity;
import com.example.mediquick.general.generalSelector;
import com.example.mediquick.medicine.medicineSelector;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class HomePage extends AppCompatActivity {

    Button cart;
    CardView general, medicine;
    ImageView ambulance, More,iconUser;
    FloatingActionButton fabChat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.homepage);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        general = findViewById(R.id.general);
        medicine = findViewById(R.id.medicines);
        ambulance = findViewById(R.id.ambulance);
        fabChat = findViewById(R.id.fabChat);
        More = findViewById(R.id.More);
        iconUser = findViewById(R.id.iconUser);

        medicine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                intent = new Intent(HomePage.this, medicineSelector.class);
                startActivity(intent);
            }
        });
        general.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                intent = new Intent(HomePage.this, generalSelector.class);
                startActivity(intent);
            }
        });

        ambulance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                Uri uri = Uri.parse("tel:108");
                intent = new Intent(Intent.ACTION_DIAL, uri);
                startActivity(intent);
            }
        });
        More.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(HomePage.this, aboutActivity.class);
                startActivity(intent);
            }
        });
        iconUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                intent = new Intent(HomePage.this, AppointmentHistoryActivity.class);
                startActivity(intent);
            }
        });
        fabChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(HomePage.this, ChatActivity.class);
                startActivity(intent);
            }
        });
    }
}
//f3facac2d6msha52789362c81d7fp1715c8jsn6053cdc4594b