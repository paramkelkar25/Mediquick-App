package com.example.mediquick.backend.interfaces;

public interface UpdateStatusCallback {
    void onSuccess(String message);
    void onFailure(String errorMessage);
}

