package com.example.mediquick.backend.interfaces;

import com.example.mediquick.backend.models.Appointment;

import java.util.List;

public interface PatientHistoryCallback {
    void onHistoryReceived(String userName, List<Appointment> history);
    void onError(String errorMessage);
}

