package com.example.mediquick.general;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mediquick.R;
import com.example.mediquick.backend.models.Doctor;

import java.util.List;

public class generalAdapter extends RecyclerView.Adapter<generalAdapter.GeneralViewHolder> {
    private final Context context;
    private final List<Doctor> generalDoctorsList;

    public generalAdapter(Context context, List<Doctor> generalDoctorsList) {
        this.context = context;
        this.generalDoctorsList = generalDoctorsList;
    }

    @NonNull
    @Override
    public GeneralViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_general, parent, false);
        return new GeneralViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GeneralViewHolder holder, int position) {
        Doctor doctor = generalDoctorsList.get(position);
        holder.txtDoctorName.setText(doctor.getName());
        holder.txtDoctorSpecialty.setText(doctor.getSpecialization());
        holder.txtRatings.setText(doctor.getRatings());
        holder.imgDoctorProfile.setImageResource(R.drawable.doctor2);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, generalDetailsActivity.class);
            intent.putExtra("doctor",doctor);
            intent.putExtra("imageResource", R.drawable.doctor2);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return generalDoctorsList.size();
    }

    static class GeneralViewHolder extends RecyclerView.ViewHolder {
        TextView txtDoctorName, txtDoctorSpecialty, txtRatings;
        ImageView imgDoctorProfile;

        public GeneralViewHolder(@NonNull View itemView) {
            super(itemView);
            imgDoctorProfile = itemView.findViewById(R.id.generalListCardImage);
            txtDoctorName = itemView.findViewById(R.id.generalListDoctorName);
            txtDoctorSpecialty = itemView.findViewById(R.id.generalListDoctorSpecialization);
            txtRatings = itemView.findViewById(R.id.generalListDoctorRating);
        }
    }
}
