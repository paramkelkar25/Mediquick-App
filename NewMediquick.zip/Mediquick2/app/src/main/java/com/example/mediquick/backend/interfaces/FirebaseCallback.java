package com.example.mediquick.backend.interfaces;

public interface FirebaseCallback {
    void onCallback(boolean isRegistered);
}
