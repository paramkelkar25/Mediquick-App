package com.example.mediquick.AppointmentHistory;

public class Appointment {
    private String DoctorName;
    private String AppointmentDate;
    private String AppointmentTime;

    public Appointment() {
        // Required empty constructor for Firebase
    }

    public Appointment(String doctorName, String appointmentDate, String appointmentTime) {
        this.DoctorName = doctorName;
        this.AppointmentDate = appointmentDate;
        this.AppointmentTime = appointmentTime;
    }

    public String getDoctorName() {
        return DoctorName;
    }

    public void setDoctorName(String doctorName) {
        this.DoctorName = doctorName;
    }

    public String getAppointmentDate() {
        return AppointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.AppointmentDate = appointmentDate;
    }

    public String getAppointmentTime() {
        return AppointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.AppointmentTime = appointmentTime;
    }
}
