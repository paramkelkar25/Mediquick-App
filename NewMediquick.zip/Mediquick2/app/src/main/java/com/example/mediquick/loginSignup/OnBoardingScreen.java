package com.example.mediquick.loginSignup;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;

import com.example.mediquick.R;
import com.example.mediquick.backend.BackendManager;
import com.example.mediquick.backend.models.User;

import java.util.HashMap;
import java.util.Objects;

public class OnBoardingScreen extends AppCompatActivity {

    private HashMap<String, String> onBoardingData;
    private User onBoardingUser;
    private final BackendManager dbManager = new BackendManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_on_boarding_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .add(R.id.onBoardingScreenFragmentContainer, new OnBoardingFragment())
                .addToBackStack("Part1")
                .commit();
    }

    public void receiveUserData(User user) {
        if (onBoardingUser == null) {
            onBoardingUser = new User();
        }

        // Update the user object with new details
        if (user.getFullName() != null) onBoardingUser.setFullName(user.getFullName());
        if (user.getContactNumber() != null) onBoardingUser.setContactNumber(user.getContactNumber());
        if (user.getAddress() != null) onBoardingUser.setAddress(user.getAddress());
        if (user.getGender() != null) onBoardingUser.setGender(user.getGender());
        if (user.getDOB() != null) onBoardingUser.setDOB(user.getDOB());
        if (user.getBloodGroup() != null) onBoardingUser.setBloodGroup(user.getBloodGroup());

        // Check if all required details are filled
        if (!Objects.equals(onBoardingUser.getFullName(), "") &&
                !Objects.equals(onBoardingUser.getContactNumber(), "") &&
                !Objects.equals(onBoardingUser.getAddress(), "") &&
                !Objects.equals(onBoardingUser.getGender(), "") &&
                !Objects.equals(onBoardingUser.getDOB(), "") &&
                !Objects.equals(onBoardingUser.getBloodGroup(), "")) {

            dbManager.addUserDetail(onBoardingUser);
            finish();
            Intent intent = new Intent(this, HomePage.class);
            startActivity(intent);
        }
    }

}