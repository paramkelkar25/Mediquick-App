package com.example.mediquick.AppointmentHistory;

import  com. example. mediquick. backend. models. Appointment;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mediquick.R;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AppointmentHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AppointmentHistoryAdapter adapter;
    private List<Appointment> appointments;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_history);

        recyclerView = findViewById(R.id.recyclerUserHistory);
        progressBar = findViewById(R.id.progressBarUserHistory);

        appointments = new ArrayList<>();
        adapter = new AppointmentHistoryAdapter(appointments);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            loadUserHistory(currentUser.getUid());
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadUserHistory(String userId) {
        progressBar.setVisibility(View.VISIBLE);
        DatabaseReference appointmentsRef = FirebaseDatabase.getInstance().getReference("appointments");

        appointmentsRef.orderByChild("userId").equalTo(userId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        appointments.clear();
                        for (DataSnapshot appointmentSnapshot : snapshot.getChildren()) {
                            Appointment appointment = appointmentSnapshot.getValue(Appointment.class);
                            if (appointment != null) {
                                // Manually adding variables according to the AppointmentHistoryAdapter's fields
                                String appointmentId = appointment.getAppointmentId();
                                String doctorId = appointment.getDoctorId();
                                String date = appointment.getDate();
                                String status = appointment.getStatus();
                                String diagnosis = appointment.getDiagnosis();
                                String createdAt = appointment.getCreatedAt();

                                // Add the appointment to the list
                                appointments.add(appointment);

                                // Optionally, you could update the status here or call a method to do so
                                // For example: appointment.setStatus("Updated Status");
                            }
                        }
                        adapter.notifyDataSetChanged();
                        progressBar.setVisibility(View.GONE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(AppointmentHistoryActivity.this, "Failed to load history", Toast.LENGTH_SHORT).show();
                        Log.e("Firebase", error.getMessage());
                        progressBar.setVisibility(View.GONE);
                    }
                });
    }
}