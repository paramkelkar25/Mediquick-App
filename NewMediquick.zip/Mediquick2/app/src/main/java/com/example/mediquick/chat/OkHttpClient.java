package com.example.mediquick.chat;

public class OkHttpClient {
}
