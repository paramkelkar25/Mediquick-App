package com.example.mediquick.general;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.backend.models.Doctor;
import com.example.mediquick.booking.BookingActivity;
import com.example.mediquick.R;

public class generalDetailsActivity extends AppCompatActivity {
    private ImageView imgDoctorProfile;
    private TextView txtDoctorName, txtDoctorSpecialty;
    private Button btnBookAppointment, btnCallDoctor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_details);

        imgDoctorProfile = findViewById(R.id.imgDoctorProfile);
        txtDoctorName = findViewById(R.id.generalListDoctorName);
        txtDoctorSpecialty = findViewById(R.id.txtDoctorSpecialty);
        btnBookAppointment = findViewById(R.id.btnBookAppointment);
        btnCallDoctor = findViewById(R.id.btnCallDoctor);

        // Get data from Intent
        Intent intent = getIntent();
        Doctor doctor = (Doctor) getIntent().getSerializableExtra("doctor");
        String doctorName = doctor.getName();
        String specialization = doctor.getSpecialization();
        int imageResource = intent.getIntExtra("imageResource", 0);

        // Set values
        txtDoctorName.setText(doctorName);
        txtDoctorSpecialty.setText(specialization);
        imgDoctorProfile.setImageResource(imageResource);

        btnBookAppointment.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(generalDetailsActivity.this, BookingActivity.class);
                intent.putExtra("doctor",doctor);
                startActivity(intent);

            }
        });
        btnCallDoctor.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent;
                Uri uri = Uri.parse("tel:9898057282");
                intent = new Intent(Intent.ACTION_DIAL, uri);
                startActivity(intent);
            }
        });
    }
}
