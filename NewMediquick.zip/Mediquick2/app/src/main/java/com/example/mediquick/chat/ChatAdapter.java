package com.example.mediquick.chat;

import android.util.Pair;

import java.util.List;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mediquick.R;

import java.util.ArrayList;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {
    private final List<Pair<String, Boolean>> messages;

    public ChatAdapter(ArrayList<Pair<String, Boolean>> messages) {
        this.messages = messages;
    }

    public static class ChatViewHolder extends RecyclerView.ViewHolder {
        TextView messageText;
        LinearLayout layout;

        public ChatViewHolder(@NonNull View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.textViewMessage);
            layout = (LinearLayout) itemView;
        }
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_message, parent, false);
        return new ChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        Pair<String, Boolean> messagePair = messages.get(position);
        String message = messagePair.first;
        boolean isSender = messagePair.second;

        holder.messageText.setText(message);

        if (isSender) {
            holder.messageText.setTextColor(Color.BLACK);
            holder.messageText.setBackgroundResource(R.drawable.chat_bubble_background); // Sender Bubble
        } else {
            holder.messageText.setTextColor(Color.WHITE);
            holder.messageText.setBackgroundResource(R.drawable.chat_bubble_receiver_background); // Receiver Bubble
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }
}

