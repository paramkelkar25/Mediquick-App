package com.example.mediquick.general;

public class general {
    private String name;
    private String specialization, ratings;
    private int imageResource;

    public general(String name, String specialization, int imageResource,String ratings) {
        this.name = name;
        this.specialization = specialization;
        this.ratings = ratings;
        this.imageResource = imageResource;
    }

    public String getName() {
        return name;
    }

    public String getSpecialization() {
        return specialization;
    }
    public String getRatings() {return ratings;}
    public int getImageResource() {return imageResource;}
}

