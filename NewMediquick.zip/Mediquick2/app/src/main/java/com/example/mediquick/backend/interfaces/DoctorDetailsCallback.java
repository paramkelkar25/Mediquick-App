package com.example.mediquick.backend.interfaces;

import com.example.mediquick.backend.models.Doctor;

public interface DoctorDetailsCallback {
    void onDoctorDetailsReceived(Doctor doctor);
}
