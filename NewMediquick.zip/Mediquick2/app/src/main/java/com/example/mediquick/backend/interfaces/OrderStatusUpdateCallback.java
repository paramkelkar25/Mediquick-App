package com.example.mediquick.backend.interfaces;


public interface OrderStatusUpdateCallback {
    void onSuccess(String message);
    void onFailure(String error);
}
